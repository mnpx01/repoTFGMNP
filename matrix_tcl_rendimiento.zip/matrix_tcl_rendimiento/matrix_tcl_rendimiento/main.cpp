#include "klee/klee.h"
#include "math.h"
#include <iostream>
#include "matrix2.h"

typedef techsoft::matrix<double> dMatrix;

int main() {
  
    int a = 0;
    klee_make_symbolic(&a, sizeof(a), "a");
    dMatrix m(a, 3);
}
