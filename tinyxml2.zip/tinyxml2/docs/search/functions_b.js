var searchData=
[
  ['openelement_0',['OpenElement',['../classtinyxml2_1_1_x_m_l_printer.html#a20fb06c83bd13e5140d7dd13af06c010',1,'tinyxml2::XMLPrinter']]],
  ['operator_3d_1',['operator=',['../classtinyxml2_1_1_x_m_l_handle.html#aa07c9a53f78d7b2dc1018668641521d8',1,'tinyxml2::XMLHandle']]]
];
