var searchData=
[
  ['read_20attributes_20and_20text_20information_0',['Read attributes and text information.',['../_example_4.html',1,'']]],
  ['rootelement_1',['RootElement',['../classtinyxml2_1_1_x_m_l_document.html#a0e6855771cbe87d839fb301d3646f5b8',1,'tinyxml2::XMLDocument']]]
];
